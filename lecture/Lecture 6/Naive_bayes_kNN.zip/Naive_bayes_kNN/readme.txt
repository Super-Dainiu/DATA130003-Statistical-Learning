catalogs.csv：商品名称、商品所属的一级、二级、三级品类
userdict.dat：自定义词典
